package troops;

public class Factory {
    public int team;
    public int x;
    public int y;

    public Factory(int _team, int _x, int _y) {
        this.team = _team;
        this.x = _x;
        this.y = _y;
    }
}
